#define rele 26
#define potenc 34

void setup() {
  Serial.begin(115200);
  pinMode(rele, OUTPUT);
}

void loop(){
  int valor = analogRead(potenc);
  Serial.println(valor);
  delay(1000);
  if (valor > 2047){
    digitalWrite(rele, LOW);
    Serial.println("RELÉ FECHADO");
  }
  else{
    digitalWrite(rele, HIGH);
    Serial.println("RELÉ ABERTO");
  }
}